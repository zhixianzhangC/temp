
system_content = "You are trained to interpret abd extract information from images and its text. Only give runnable python code"

def settlement_list_prompt(settlement_list_text=None, settlement_list_image=None):
    
    query = [  
        {
            "type": "text",
            "text":
            f"""Extract the information from the settlement image and the settlement text, includes :
            1. the type of service (item name): classify into '餐饮', '住宿'，‘交通’，'服务' or others
            2. The service outsourced or not
            3. the name of the service provider: if the provider is emmpty, do not extract the current row.
            4. the end level invoice number,
            5. the subtotal price for each item under "Contract/PO Amount" and "Actual", respectively,
            6. whether it is 专用 or not.  

            - Give me the python code for making it a python pandas dataframe named df_details.
            - The dataframe columns should be: ['服务类型    是否外包    外包服务供应商名称   终端发票号码    合同小计  实际小计    是否专用'].
            - Extract me the final subtotal of "增值税后总金额" of contract/PO amount and the actual amount as df_details.loc[df_details['服务类型'] == '增值税后总金额', '合同小记'] and df_details.loc[df_details['服务类型'] == '增值税后总金额', '实际小计']
            - Remember concatenate the rows with correct syntax. Dataframe has no attribute "append".
            - Keep each column unique and no replications, regarding 服务类型 and 小计.
            - All information must be in the dataframe. Do not give me other variables. You can use the chart in the image to help you extract useful information.
            - the length of each row should be the same in order to build pd dataframe. Give me only the codes and no other explanations because I am going to directly execute your answer by python.

            Here are the extracted text from the settlement image:
                {settlement_list_text}

            - Also, provide me with a separate dataframe called 'df_settle_event' showing the Event name, location and date.
            
            REQUEST:
            - Only give me the PYTHON CODE for 'df_details' and 'df_settle_event' generation
            - The '服务类型' in df_details should be classified into '餐饮', '住宿'，‘交通’，'服务' or other similar type.
            - Carefully maker sure the number in the dataframe is correct.
            - make sure the columns name is :['服务类型 外包服务供应商名称   终端发票号码    合同小计  实际小计    是否专用']
            - make sure use '增值税后总金额' in df_details['服务类型']
            """},
        {
            "type": "image_url",
            "image_url": {
                "url": f"data:image/jpeg;base64,{settlement_list_image}"
            },
        },
    ]
    return query

def invoice_prompt(invoice_text_list=None, invoice_image_list=None, categories=None):
    text_content = f"""Extract the information from the given invoice text and the invoice image.
                    the information includes:
                    1. the type of service: classify as one type in the list {categories}.
                    2. the name of the buyer and seller.
                    3. the end level invoice number.
                    4. the actual price before tax.
                    5. the amount of tax.
                    6. the type of invoice: classify as '专用' or '普通'
 
                    - Give me the correct python code for making it a python pandas dataframe named ‘df_invoice’, with columns [购买方  销售方  发票号码    价税合计  服务类型    金额  税额  发票类型].
                    - the length of each row should be the same in order to build pandas dataframe.
                    - the length of the dataframe should be the same as the number of given invoice, because each invoice should be extracted.
                    - Only give me the PYTHON CODE for 'df_invoice' generation.
                    - the '服务类型' in df_invoice must be one of the {categories}.
 
                    the below are the extracted invoice text. The text may not be accurate so you can modify as you wish.
                    {invoice_text_list}
 
                    REQUEST:
                    - Carefully maker sure the number in the dataframe is correct.
                    - In the columns of "金额", "税额", "价税合计"，give me only numbers. Symbols of currency are not allowed to be output in the dataframe.
                    - Only give PYTHON code.
                    """
    messages_image = [{"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{data_url}"}} for data_url in invoice_image_list]
    
    query = [{"type": "text", "text": text_content}] + messages_image

    return query


def confirm_prompt(confirm_text=None, confirm_url=None):
    query = [  
            {
                "type": "text",
                "text":
                f"""Based on the information in confirm_text {confirm_text} and the image of confirmation email, find the event name, location and date. Also, give me the email of 发件人 and 收件人 in this confirmation email. Also, extract the amount details in the {confirm_text}.
                    The confirm text is extracted from the user image, so use both the image and the text to help you make decisions.
                    
                    Output should be code generating a pandas dataframe called 'df_confirm' with columns:
                    [- 会议名称 - 会议地点 - 会议时间 ]
                    And another panda dataframe called 'df_email' with columns:
                    [发件人 收件人]
                    And another panda dataframe called "df_amount_detail" with information of:
                    [确认邮件中金额明细]

                    No other text are allowed to be output.

                REQUEST:
                - Only give me the PYTHON CODE for 'df_confirm' and 'df_email' and 'df_amount_detail' generation

                """},
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{confirm_url}"
                },
            },
        ]
    return query

def quotation_prompt(settlement_list_text=None, quotation_text=None, settlement_list_image=None, quotation_image=None):
    query = [  
        {
            "type": "text",
            "text":
            f"""Based on the information in {settlement_list_text} and the image of settlement list, tell me whether the settlement list page has a stamp called "seal page checked". This page corresponds to "结算单"。
                Based on the information in the {quotation_text} and the image of quotation detal sheet, tell me whether the quoatation detail sheet has a stamp called "seal page checked". Also, extract the "供应商名称“ in the page. This page corresponds to "报价单"。

                - If the stamp with "seal page checked" is not found, then output "未找到” in the "seal page checked章" row. Otherwise, output “存在”。
                - If "供应商名称" in the quotation detail sheet not found, then output "未找到" in the "供应商名称" row. Otherwise, output the extracted information of "供应商名称"。
                
                Output Format:
                **报价单**：
                - Seal Page Checked章：
                - 供应商名称：
                **结算单**：
                - Seal Page Checked章：
            """},
        {
            "type": "image_url",
            "image_url": {
                "url": f"data:image/jpeg;base64,{settlement_list_image}"
            },
        },
        {
            "type": "image_url",
            "image_url": {
                "url": f"data:image/jpeg;base64,{quotation_image}"
            },
        },
    ]
    return query