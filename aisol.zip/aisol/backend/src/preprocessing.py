import os
import io
import fitz
import base64
from PIL import Image
import streamlit as st
from pdf2image import convert_from_path
from langchain_community.document_loaders import Docx2txtLoader, UnstructuredWordDocumentLoader,TextLoader, PyMuPDFLoader, PyPDFLoader


def pdf_load(file_name):
    pdf_loader = PyMuPDFLoader(file_name, extract_images = True)
    doc = pdf_loader.load()
    doc_page_content = [i.page_content for i in doc if i.page_content != '']
    return doc, doc_page_content

def pdf_to_base64_str_list(pdf_path, dpi=300, quality=95):
    doc = fitz.open(pdf_path)
    base64_strings = []

    for page_number in range(len(doc)):
        page = doc.load_page(page_number)
        zoom_x = dpi / 72.0
        zoom_y = dpi / 72.0
        mat = fitz.Matrix(zoom_x, zoom_y)
        pix = page.get_pixmap(matrix=mat)

        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        buffered = io.BytesIO()
        img.save(buffered, format="JPEG", quality=quality)
        img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')
        base64_strings.append(img_str)

    doc.close()
    return base64_strings

def load_uploaded_pdf(uploaded_pdf):
    if uploaded_pdf is not None:
        # Save the uploaded file to a temporary location
        temp_pdf_path = os.path.join("temp", uploaded_pdf.name)
        with open(temp_pdf_path, "wb") as f:
            f.write(uploaded_pdf.getbuffer())
        return temp_pdf_path

def replace_comma(string):
    if type(string) == str:
        if "," in string:
            number = float(string.replace(",", ""))
        else:
            number = float(string)
    else: 
        number = string
    return number