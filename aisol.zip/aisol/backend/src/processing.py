import streamlit as st
import os
from .find_indexes import find_indexes, confirm
from .preprocessing import pdf_load, pdf_to_base64_str_list, load_uploaded_pdf, replace_comma
from .open_ai_response import client_gpt4o, get_ai_response
from .page_content import no_settlement, normal_page
from .edm_config.prompts.prompts import settlement_list_prompt, invoice_prompt, confirm_prompt, quotation_prompt, system_content

# @st.cache_data
def processing(file_path):

    ## step1
    # st.info('test logging')
    st.sidebar.caption(f'1. 获取到文件{file_path}')
    st.sidebar.caption(f'2. 正在抽取文件中的文本信息...')  
    try:
        doc, doc_page_content = pdf_load(file_path)
    except Exception as e:
        print(e)
        st.sidebar.caption("抽取文本信息失败。")
    print(doc_page_content)
    st.sidebar.caption(f'共获取到{len(doc_page_content)}页信息')
    
    ## step 2
    st.sidebar.caption('3. 开始寻找关键信息的页数...')
    try:
        invoice_index_list, final_invoice_index, settlement_list_index, opera_index, quotation_index = find_indexes(doc, file_path)
    except Exception as e:
        print(e)
        st.sidebar.caption("Fail to extract index from pdf file.")
    st.sidebar.caption(f'发票index: {invoice_index_list}, 三方给拜耳的大发票: {final_invoice_index}, 结算单: {settlement_list_index}, 报价单: {quotation_index}, 系统回复邮件: {opera_index}')
    
    ## step 3
    ## need intsall: sudo apt-get install poppler-utils
    st.sidebar.caption('4. 把pdf文件转换为图片...')
    image_urls = pdf_to_base64_str_list(file_path)
    st.sidebar.caption(f'共{len(image_urls)}张图片')

    st.sidebar.caption('5. 获取结算单和发票的所有文本和图片...')

    if settlement_list_index is not None: 
        try:
            settlement_list_image = image_urls[settlement_list_index]
            settlement_list_text = doc_page_content[settlement_list_index]
        
        except Exception as e:
            print(e)
            st.sidebar.caption("Error in extracting indexes.")

    invoice_image_list = [image_urls[i] for i in invoice_index_list]
    invoice_text_list = [doc_page_content[i] for i in invoice_index_list]
    st.sidebar.caption('完成')

    if settlement_list_index is None: 
        st.sidebar.caption("结算单未找到，提取发票信息并展示")
        no_settlement(invoice_text_list, invoice_image_list, client_gpt4o, opera_index, quotation_index)   
        return

    # step 4
    st.sidebar.caption('6. 使用gpt4o 抽取结算单中信息...')
    if settlement_list_index is not None:
        settlement_list_query = settlement_list_prompt(settlement_list_text, settlement_list_image)
        rp_settle = get_ai_response(settlement_list_query)
        st.sidebar.caption('抽取完毕')

        with st.expander('code for df_details and df_settle_event'):
            st.code(rp_settle[10:len(rp_settle)-4])
        local_vars = {}
        exec(rp_settle[10:len(rp_settle)-4], {}, local_vars)
        df_details = local_vars['df_details']
        df_settle_event = local_vars['df_settle_event']
    
        categories = str(set(df_details["服务类型"]))

    # step 5
    st.sidebar.caption('7 开始处理所有的小发票...')

    #GPT提取所有发票信息
    invoice_query = invoice_prompt(invoice_text_list, invoice_image_list, categories)
    rp_invoice = get_ai_response(invoice_query)
 
    with st.expander('code for df_invoice'):
        st.code(rp_invoice[10:len(rp_invoice)-4])
    local_vars_1 = {}
    exec(rp_invoice[10:len(rp_invoice)-4], {}, local_vars_1)
    df_invoice = local_vars_1['df_invoice']
    st.sidebar.caption('抽取完毕')

   
    # step 6
    st.sidebar.caption('8 对比确认邮件中的信息和结算单中的信息是否一致...')
    confirm_index = confirm(doc, invoice_index_list, final_invoice_index, settlement_list_index, opera_index, quotation_index)
    confirm_url = image_urls[confirm_index]
    confirm_text = doc_page_content[confirm_index]
    confirm_query = confirm_prompt(confirm_text, confirm_url)
    rp_confirm = get_ai_response(confirm_query)

    with st.expander('code for df_confirm'):
        st.code(rp_confirm[10:len(rp_confirm)-4])
    local_vars_2 = {}
    exec(rp_confirm[10:len(rp_confirm)-4], {}, local_vars_2)
    df_confirm = local_vars_2['df_confirm']
    df_email = local_vars_2['df_email']
    df_amount_detail = local_vars_2['df_amount_detail']

    st.sidebar.caption(f'对比完毕')
 
    # step 7
    st.sidebar.caption('9 提取报价单和结算单信息')
    if quotation_index is not None:
        quotation_image = image_urls[quotation_index]
        quotation_text = doc_page_content[quotation_index]
        quotation_query = quotation_prompt(settlement_list_text, quotation_text, settlement_list_image, quotation_image)
    else:
        quotation_query = quotation_prompt(settlement_list_text, _, settlement_list_image, _)
        st.sidebar.caption("报价单未找到，请手动审核原文件")
    
    
    rp_quotation = get_ai_response(quotation_query)

    st.sidebar.caption(f'提取完毕')
   
    df_final_invoice = df_invoice.loc[df_invoice['购买方'] == "拜耳医药保健有限公司"]
    df_invoice = df_invoice.loc[df_invoice['购买方'] != "拜耳医药保健有限公司"]
   
    st.sidebar.caption('9 开始进行一致性校对...')
    normal_page(df_details, df_invoice, df_final_invoice, df_settle_event, df_confirm, df_email, df_amount_detail, rp_quotation, settlement_list_index, confirm_index, opera_index, quotation_index)
    return
 
