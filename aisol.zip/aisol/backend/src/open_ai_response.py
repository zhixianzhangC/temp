import os
from openai import AzureOpenAI

os.environ['AZURE_OPENAI_ENDPOINT'] = 'https://edm.openai.azure.com/'
os.environ['AZURE_OPENAI_API_KEY'] = 'd48a519eb93d43f2bd2e44cc462658d4'
os.environ['DEVEOPMENT_NAME'] = 'gpt-4o-2024-05-13'
os.environ['API_VERSION'] = '2024-02-01' # this might change in the future

open_ai_key = os.getenv('AZURE_OPENAI_API_KEY')
api_version = os.getenv('API_VERSION')
azure_endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')
open_ai_deployment_name = os.getenv('DEVEOPMENT_NAME')
    
client_gpt4o = AzureOpenAI(api_key=open_ai_key, azure_endpoint=azure_endpoint, api_version=api_version)

def get_ai_response(query, client=client_gpt4o, open_ai_deployment_name=open_ai_deployment_name, system_content = "You are trained to interpret and extract information from images and its text. Only give runnable python code") -> str:

    try:
        message_text = [
            {"role": "system", "content": system_content},
            {"role": "user", "content": query},
        ]

        response = client.chat.completions.create(
            model=open_ai_deployment_name,
            messages=message_text,
            temperature=0,
            seed=15,
        )

        return response.choices[0].message.content
    except Exception as e:
        print(e)
        return "Sorry, I am unable to provide an answer at this time"
