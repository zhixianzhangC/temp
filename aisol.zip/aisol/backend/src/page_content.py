import streamlit as st
import pandas as pd
import os
from .open_ai_response import client_gpt4o, get_ai_response
from .preprocessing import replace_comma
from .edm_config.prompts.prompts import settlement_list_prompt, invoice_prompt, confirm_prompt, quotation_prompt, system_content

#没有结算单的page
def no_settlement(invoice_text_list, invoice_image_list, client_gpt4o, opera_index, quotation_index, categories=None):

    invoice_query = invoice_prompt(invoice_text_list, invoice_image_list)
    rp_invoice = get_ai_response(invoice_query)

    with st.expander('code for df_invoice'):
        st.code(rp_invoice[10:len(rp_invoice)-4])
    local_vars_1 = {}
    exec(rp_invoice[10:len(rp_invoice)-4], {}, local_vars_1)
    df_invoice = local_vars_1['df_invoice']
    st.sidebar.caption('发票信息抽取完毕')

    #第一大点
    st.subheader('1 对比【大发票】与【结算单】金额是否一致')
    st.write('**结算单未找到，请手动审核原文件**')

    #第二大点
    st.subheader('2 对比【确认邮件】和【结算单】是否一致')
    st.write('**结算单未找到，请手动审核原文件**')
    #第三大点

    st.subheader('3【五角星Opera邮件】信息')
    if opera_index is not None:
        st.write("**Opera邮件存在，在第" + str(opera_index + 1) + "页**")
    else:
        st.write("**Opera邮件未找到，请手动审核原文件**")
    st.divider()

    #第四大点

    st.subheader('4【报价单】与【结算单】基本信息')
    if quotation_index is not None:
        st.write(f"**报价单存在，在第{quotation_index + 1}页**")
    else:
        st.write("**报价单未找到，请手动审核原文件**")

    st.write("**结算单未找到，请手动审核原文件**")
    # st.write(rp_quotation)
    st.divider()

    #第五大点

    st.subheader('5 对比【结算单】和【小发票】是否一致')
    try:
        # 移除或替换空字符串或其他无法转换为浮点数的值

        def update_value(row):
            if row['发票类型'] == '专用':
                return row['金额']
            else:
                return row['价税合计']

        # Apply the function to the 价税合计 column
        df_invoice['价税合计'] = df_invoice.apply(update_value, axis=1)
        df_invoice['发票所在页'] = ''
        for i in range(len(df_invoice)):
            for j in range(len(invoice_text_list)):
                if df_invoice['发票号码'].values[i] in invoice_text_list[j]: #这里可优化
                        idx = invoice_index_list[j]
                        df_invoice['发票所在页'].values[i] = idx+1
                        break
        with st.expander('dataframe of new and df_invoice'):
            st.dataframe(new)
            st.dataframe(df_invoice)
        df_new = new.merge(df_invoice, left_on=['实际小计', '服务类型'], right_on=['价税合计', '服务类型'], how='outer')

    except Exception as e:
        st.write('对比存在问题，请您自行查阅下面抽取的结算单、小发票中的信息')

    st.write("发票提取信息\n")
    st.dataframe(df_invoice)
    st.sidebar.caption('处理完毕')
    return


#有结算单的page
def normal_page(df_details, df_invoice, df_final_invoice, df_settle_event, df_confirm, df_email, df_amount_detail, rp_quotation, settlement_list_index, confirm_index, opera_index, quotation_index):
    #第一大点

    st.subheader('1 对比【大发票】与【结算单】金额是否一致')
 
    x = replace_comma(df_details.loc[df_details['服务类型'] == '增值税后总金额', '实际小计'].values[0])
    y = replace_comma(df_final_invoice.loc[df_final_invoice['购买方'] == '拜耳医药保健有限公司', '价税合计'].values[0])
    try:
        if x == y:
            st.write("一致, 金额为" + str(x))
        else:
            st.write("似乎不一致. 大发票金额为：" + str(y) +"；结算单金额为：" + str(x))
    except Exception as e:
        st.write('对比存在问题，请您自行查阅下面抽取的结算单、大发票中的信息')
        st.dataframe(df_details)
        st.dataframe(df_final_invoice)
    st.divider()
 
    #第二大点
    st.subheader('2 对比【确认邮件】和【结算单】是否一致')
    st.write(f"**第{settlement_list_index + 1}页 结算单中会议详情**")
    st.dataframe(df_settle_event)
    st.write(f"**第{confirm_index + 1}页 确认邮件中会议详情**")
    st.dataframe(df_confirm)
    st.write(f"**第{confirm_index + 1}页 确认邮件中发件人,收件人与会议金额明细**")
    st.dataframe(df_email)
    st.dataframe(df_amount_detail)
    st.divider()

    #第三大点
 
    st.subheader('3【五角星Opera邮件】信息')
    if opera_index is not None:
        st.write("**Opera邮件存在，在第" + str(opera_index + 1) + "页**")
    else:
        st.write("**Opera邮件未找到，请手动审核原文件**")
    st.divider()
 
    #第四大点
 
    st.subheader('4【报价单】与【结算单】基本信息')
    if quotation_index is not None:
        st.write(f"**报价单存在，在第{quotation_index + 1}页**")
    else:
        st.write("**报价单未找到，请手动审核原文件**")
    if settlement_list_index is not None:
        st.write(f"**结算单存在，在第{settlement_list_index + 1}页**")
    else:
        st.write("**结算单未找到，请手动审核原文件**")
    st.write(rp_quotation)
    st.divider()
 
    #第五大点
 
    st.subheader('5 对比【结算单】和【小发票】是否一致')
    try:
        # 移除或替换空字符串或其他无法转换为浮点数的值
        df_details['实际小计'] = df_details['实际小计'].replace('', np.nan).str.replace(',', '')
 
        # 将列转换为浮点数
        df_details['实际小计'] = df_details['实际小计'].astype(float)
        df_details_new = df_details[df_details['终端发票号码'] != ""]
        new = df_details_new.groupby(['服务类型', '外包服务供应商名称', '终端发票号码', '是否专用'])['实际小计'].sum().reset_index()
 
        def update_value(row):
            if row['发票类型'] == '专用':
                return row['金额']
            else:
                return row['价税合计']
 
        # Apply the function to the 价税合计 column
        df_invoice['价税合计'] = df_invoice.apply(update_value, axis=1)
        df_invoice['发票所在页'] = ''
        for i in range(len(df_invoice)):
            for j in range(len(invoice_text_list)):
                if df_invoice['发票号码'].values[i] in invoice_text_list[j]: #这里可优化
                        idx = invoice_index_list[j]
                        df_invoice['发票所在页'].values[i] = idx+1
                        break
        with st.expander('dataframe of new and df_invoice'):
            st.dataframe(new)
            st.dataframe(df_invoice)
        df_new = new.merge(df_invoice, left_on=['实际小计', '服务类型'], right_on=['价税合计', '服务类型'], how='outer')
        text_list = []
        for i in range(len(df_new)):
            if type(df_new['外包服务供应商名称'][i]) != str:
                idx = df_new['发票所在页'][i]
                if type(idx) != str:
                    text_list.append(f"第{idx}页中发票与结算单中信息不匹配")
                else:
                    text_list.append(f"发票号为“{df_new['发票号码'][i]}”的发票与结算单中信息不匹配")
 
            elif type(df_new['购买方'][i]) != str:
                text_list.append(f"结算单中服务商为“{df_new['外包服务供应商名称'][i]}”，发票号码为“{df_new['终端发票号码'][i]}”，实际小计为“{df_new['实际小计'][i]}”的项目无发票对应或对应有误")
 
            else:
                idx = df_new['发票所在页'][i]
                text_list.append(f"对应正确：结算单中服务商为“{df_new['外包服务供应商名称'][i]}”，发票号码为“{df_new['终端发票号码'][i]}”，实际小计为“{df_new['实际小计'][i]}”的项目与第{idx+1}页发票对应无误。")
 
        text_list = sorted(text_list)
        for i in text_list:
            st.write(f'- {i}')
    except Exception as e:
        st.write('对比存在问题，请您自行查阅下面抽取的结算单、小发票中的信息')
   
    st.write("结算单提取信息\n")
    st.dataframe(df_details)
    st.write("发票提取信息\n")
    st.dataframe(df_invoice)
    st.sidebar.caption('处理完毕')    
    return 