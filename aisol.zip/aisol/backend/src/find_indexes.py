import os
import streamlit as st

def find_indexes(doc, file_path):

    final_invoice_index = None
    invoice_index = []
    settle_index = None
    opera_index = None
    quotation_index = None
    temp_final_invoice = 0
    temp_settle = 0
    temp_opera = 0
    temp_quotation = 0

    for doc_index in range(len(doc)):
        if ('SETTLEMENT' in doc[doc_index].page_content or '会议结算清单' in doc[doc_index].page_content) and temp_settle == 0:
            settle_index = doc_index
            temp_settle += 1
        elif '用发票' in doc[doc_index].page_content or '通发票' in doc[doc_index].page_content or '机器编号' in doc[doc_index].page_content:
            if '拜耳医药保健有限公司' in doc[doc_index].page_content and temp_final_invoice == 0:
                final_invoice_index = doc_index
                temp_final_invoice += 1
            invoice_index.append(doc_index)
        elif ('opera' in doc[doc_index].page_content or 'OPERA' in doc[doc_index].page_content) and temp_opera == 0:
            opera_index = doc_index
            temp_opera += 1
        elif 'Quotation' in doc[doc_index].page_content and temp_quotation == 0:
            quotation_index = doc_index
            temp_quotation += 1
        else:
            pass

    match (len(invoice_index), temp_settle, temp_opera, temp_quotation, temp_final_invoice):
        case (0, _, _, _, _):
            st.sidebar.caption("小发票未找到")
            print("小发票未找到")
        case (_, 0, _, _, _):
            st.sidebar.caption("结算单未找到")
            print("结算单未找到")
        case (_, _, 0, _, _):
            st.sidebar.caption("Opera确认邮件未找到")
            print("Opera确认邮件未找到")
        case (_, _, _, 0, _):
            st.sidebar.caption("报价单未找到")
            print("报价单未找到")
        case (_, _, _, _, 0):
            st.sidebar.caption("大发票未找到")
            print("大发票未找到")
       
    return invoice_index, final_invoice_index, settle_index, opera_index, quotation_index
 
def confirm(doc, invoice_index_list, final_invoice_index, settlement_list_index, opera_index, quotation_index):
    temp_confirm = 0
    confirm_index = None
    invoice_index_list.extend([settlement_list_index, opera_index, quotation_index])
    full_list = list(range(len(doc)))
    filtered_list = list(filter(lambda x: x not in invoice_index_list, full_list))
    for doc_index in filtered_list:
        if ('会议名称' in doc[doc_index].page_content  or '会议时间' in doc[doc_index].page_content or '会议地点' in doc[doc_index].page_content) and temp_confirm == 0:  
            confirm_index = doc_index
            temp_confirm += 1
    return confirm_index