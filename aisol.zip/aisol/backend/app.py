import streamlit as st
import os
from PIL import Image
from src.processing import processing
from src.find_indexes import find_indexes, confirm
from src.preprocessing import pdf_load, pdf_to_base64_str_list, load_uploaded_pdf, replace_comma
from src.open_ai_response import client_gpt4o, get_ai_response

st.set_page_config(page_title = "Bayer EDM: Generative AI empowered Doc Check ", page_icon = Image.open('../static/bayer.jpg'), layout = "wide")

def main():
    st.sidebar.image(Image.open('../static/sidebar.jpg'), caption = '')

    st.sidebar.divider()
    st.sidebar.caption( """
        免责声明 \n
    当前平台仅用于测试，请在模型处理完毕后进行查验。
        """, unsafe_allow_html = True)
    st.sidebar.divider()
   
 
    st.title("GPT赋能的EDM相关文档的一致性校对")
    st.markdown("""
    上传您的EPRM文档，我们将为您进行一致性校验，大概需要10～分钟，在此期间**请勿关闭当前界面或熄屏**：
    - 对比【大发票】与【结算单】是否一致
    - 对比【确认邮件】和【结算单】是否一致
    - 查看【五角星Opera邮件】信息
    - 查看【报价单】与【结算单】基本信息
    - 对比【结算单】和【小发票】是否一致
   
    考虑到平台为demo版本，如果您在使用过程中出现错误，请你刷新界面重新提交文件。
 
    如果仍然存在问题，请将您上传的文件、界面截图、左边栏的处理过程，发送到邮箱：danping.jia@bayer.com
   
    """)
    st.divider()
    uploaded_pdf = st.file_uploader("上传您的文档", type=['pdf'])
    confirm_button = st.button('确认提交', type= 'primary')
    if uploaded_pdf is not None and confirm_button is True:
        if not os.path.exists("temp"):
                os.makedirs("temp")    
        pdf_path = load_uploaded_pdf(uploaded_pdf)
        # try:
        st.sidebar.caption('**处理过程**')
        st.write('平台正在处理您上传的文件，请勿重复点击按钮。您可以在左边栏查看处理进程')
        processing(pdf_path)
        # except Exception as e:
        #     st.error('系统出错，请您联系Zhixian或Danping')
 
 
 
if __name__ == "__main__":
    main()