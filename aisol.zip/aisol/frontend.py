import os
import io
import json
import time
import datetime
from PIL import Image
import boto3
import pickle
import pandas as pd


import streamlit as st
from streamlit_chat import message
from streamlit.web.server.websocket_headers import _get_websocket_headers
import openai
import shutil
import fitz


from langchain_community.document_loaders import Docx2txtLoader, UnstructuredWordDocumentLoader,TextLoader, PyMuPDFLoader, PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter, MarkdownHeaderTextSplitter, RecursiveCharacterTextSplitter
from langchain.indexes import VectorstoreIndexCreator
from langchain.embeddings import OpenAIEmbeddings, AzureOpenAIEmbeddings
from langchain.vectorstores import Chroma, DocArrayInMemorySearch
from langchain.chains.llm import LLMChain
from langchain.chains import RetrievalQA, ConversationalRetrievalChain
from langchain.prompts.prompt import PromptTemplate
from langchain.chat_models import ChatOpenAI, AzureChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.memory.chat_message_histories import StreamlitChatMessageHistory
from langchain.callbacks.base import BaseCallbackHandler
from langchain.schema.runnable import RunnableParallel
from langchain.prompts import ChatPromptTemplate
from langchain.schema.runnable import RunnablePassthrough, RunnableLambda
from langchain.schema.output_parser import StrOutputParser

import jwt

import logging

import pysqlite3
import sys
import base64
try:
    sys.modules["sqlite3"] = sys.modules.pop("pysqlite3")
except Exception as e:
    sys.modules['sqlite3'] = __import__('pysqlite3')
import chromadb

## change to gpt-4-32k because of speed
# endpoint_url = 'https://eventdocreadinesscheckgpt4.openai.azure.com/' ## gpt4-turbo
# 'https://eventdocreadinessgptnew.openai.azure.com/' ## gpt-4
endpoint_url = 'https://eventdocreadinessgptnew.openai.azure.com/'
openai.api_type = 'azure'
openai.api_base = endpoint_url
openai.api_version = '2023-05-15'
# '11c9347ec2454c64aa0ea565a7c235ba' ## gpt4-turbo
# '70645091996e48fdbc9de1dda62aaa4c ## gpt-4
openai.api_key = '70645091996e48fdbc9de1dda62aaa4c'
os.environ["OPENAI_API_KEY"] = '70645091996e48fdbc9de1dda62aaa4c'
os.environ["AZURE_OPENAI_API_KEY"] = '70645091996e48fdbc9de1dda62aaa4c'
os.environ["AZURE_OPENAI_ENDPOINT"] = endpoint_url

os.environ['STREAMLIT_SERVER_ENABLE_STATIC_SERVING'] = 'true'

st.set_page_config(page_title = "Event Document Readiness Check", page_icon = Image.open('static/bayer_logo.png'), layout = "wide", initial_sidebar_state = "collapsed")
logging.basicConfig(format ='%(asctime)s %(levelname)-8s %(message)s',level = logging.INFO,datefmt = '%Y-%m-%d %H:%M:%S')

# @st.cache_data
def validate_and_get_cwid(token):
    secret_key = 'prodCc5byA6ZSF4oCd5LqGISDov5Hml6Us6buE5rKz5YaF6JKZ5Yk5bem5reW5bC'
    try: 
        decoded_token = jwt.decode(token, secret_key, algorithms=['HS512']) 
        return decoded_token['cwid']
    except jwt.DecodeError as err:
        print("JWT Decoding Failed:", str(err))
        return None
    except jwt.ExpiredSignatureError as err:
        print("JWT Decoding Failed:", str(err))
        return None

    
def get_token_from_cookie(cookie):
    key_value_dic = {}
    key_value_list = cookie.split(';')
    for key_value in key_value_list:
        key = key_value.split('=')[0].strip()
        value = key_value.split('=')[1].strip()
        key_value_dic[key] = value
    logging.info(f'{key_value_dic}')
    return key_value_dic.get('webapp-cookie-token')
        
# @st.cache_resource
def authentication_verification():
    try:
        logging.info('try first')
        token = st.experimental_get_query_params().get('token')[0]
        logging.info(f'token : {token}')
    except Exception as e:
        logging.info('try second')
        logging.info(f'_get_websocket_headers() : {_get_websocket_headers()}')
        token = get_token_from_cookie(_get_websocket_headers().get("Cookie"))
        logging.info(f'token : {token}')
    cwid = validate_and_get_cwid(token)
    if cwid:
        return cwid
    else:
        return None
    

def if_images_in_pdf(file_name):
    pdf_document = fitz.open(file_name)
    for page_number in range(len(pdf_document)):
        page = pdf_document[page_number]
        image_list = page.get_images(full = True)
        if len(image_list) > 0:
            return True
    
def data_load(file_obj, name):
    if not os.path.exists(f'{name}'):
        os.makedirs(f'{name}')
    logging.info(f'开始处理文件:{file_obj.name}')   
    with open(f'{name}/{file_obj.name}', 'wb') as tmp_file:
        tmp_file.write(file_obj.getbuffer())
        logging.info(f'文件已经写入本地')  
        if file_obj.name.endswith('docx'):
            word_loader = Docx2txtLoader(tmp_file.name)
            doc = word_loader.load()
        elif file_obj.name.endswith('doc'): 
            word_loader1 = UnstructuredWordDocumentLoader(tmp_file.name)
            logging.info(f'special for .doc | make sure wordloader sucessfully') 
            doc = word_loader1.load()
        elif file_obj.name.endswith('pdf'):
            pdf_loader = PyMuPDFLoader(tmp_file.name, extract_images = True)
            doc = pdf_loader.load()
            # if if_images_in_pdf(tmp_file.name) is True:
            #     logging.info(f'special for pdf | having images') 
            #     try:
            #         pdf_loader = PyMuPDFLoader(tmp_file.name, extract_images = True)
            #         doc = pdf_loader.load()
            #     except Exception as e:
            #         logging.info(f'special for pdf | PyPDFLoader failed, use PyMuPDFLoader') 
            #         pdf_loader = PyMuPDFLoader(tmp_file.name)
            #         doc = pdf_loader.load()
            # else:
            #     logging.info(f'special for pdf | do not have images') 
            #     pdf_loader = PyMuPDFLoader(tmp_file.name)
            #     doc = pdf_loader.load()
        else:
            pass
    doc_page_content = [i.page_content for i in doc if i.page_content != '']
    logging.info(f'文件:{file_obj.name}load完毕')   
    if len(doc_page_content) > 0:
        doc[0].page_content = '\n'.join(i for i in doc_page_content)
        doc[0].metadata = {'source' : file_obj.name}
        logging.info(f'文件:{file_obj.name}metadata处理完毕')
        return doc[0]
    else:
        return None

# @st.cache_resource
def char_splits(_doc_obj):
    chunk_size = 3500
    chunk_overlap = 700
    text_spliter = RecursiveCharacterTextSplitter(chunk_size = chunk_size, chunk_overlap = chunk_overlap)
    splits = text_spliter.split_documents(_doc_obj)
    return splits

@st.cache_resource(show_spinner = False)
def vector_db_prepare(file_obj_name_list, name):
    logging.info('开始处理文件列表')
    vector_process = st.progress(0, text = f':red[💻 **EventDocReadinessCheck**：请等待大约10分钟：⚠请勿息屏、返回‘✉ 功能介绍及使用方法’界面、或点击提交按钮：] :blue[第一模块：文件处理]  ')
    embeddings = AzureOpenAIEmbeddings(
        azure_deployment='text-embedding-ada-002',
        openai_api_version="2023-03-15-preview",
    )
    docs_sucess = []
    docs_fail = []
    for index in range(0, len(file_obj_name_list)):
        vector_process.progress(index * 25, f':red[💻 **EventDocReadinessCheck**：请等待大约10分钟：⚠请勿息屏、返回‘✉ 功能介绍及使用方法’界面、或点击提交按钮：] :blue[第一模块：文件处理]  正在加载文件：{file_obj_name_list[index][0].name}...')
        logging.info(f'开始处理文件:{file_obj_name_list[index][0]}')
        doc = data_load(file_obj_name_list[index][0], name)
        
        if doc != None:
            docs_sucess.append(doc)
        else:
            docs_fail.append(file_obj_name_list[index][1])
    logging.info(f'所有文件load完毕')
    splited_docs = char_splits(docs_sucess)
    logging.info(f'所有文件成功切分')
    VectorDB = Chroma.from_documents(splited_docs, embeddings)
    logging.info(VectorDB)
    logging.info(f'所有文件存为了数据库')
    shutil.rmtree(f'{name}')
    logging.info(f'删用户文件夹')
    vector_process.progress(100, f':red[💻 **EventDocReadinessCheck**：请等待大约10分钟：⚠请勿息屏、返回‘✉ 功能介绍及使用方法’界面、或点击提交按钮：] :blue[第一模块：文件处理]  完成！')
    logging.info(f'所有文件变成embedding')
    vector_process.empty()
    return VectorDB, docs_fail


def vector_query_one_field(field, values):
    if len(values) == 0:
        selected_where = {field: {'$eq': ''}}
    elif len(values) == 1:
        selected_where = {field: {'$eq': values[0]}}
    else:
        selected_where_list = [{field : {'$eq': i}} for i in values]
        selected_where = {'$or' : selected_where_list}
    return selected_where

def vector_query(fields, values):
    if len(fields) == 1:
        return vector_query_one_field(fields[0], values[0])
    else:
        selected_where_all = []
        for i, j in zip(fields, values):
            selected_where_all.append(vector_query_one_field(i, j))
        return {'$and': selected_where_all}

def vector_db_filtered(vector_db, document_where_value):
    return vector_db.get(where = document_where_value)    

def qa_model_chain():
    template = """Answer the question based only on the following context:
    {context}

    Question: {question}
    
    1. Answer in the following language: Chinese.
    2. Please think step-by-step. 
    3. Please always make the info more readable: highlight the important information, list key points.
    4. please always answer the question carefully and with professional logic.
    """
    model = AzureChatOpenAI(streaming=True, openai_api_version="2023-05-15",model = "gpt-4-32k", temperature = 0.4) ## seed = 7, model="gpt-4-1106-preview",gpt-4-32k
    chain = ChatPromptTemplate.from_template(template) | model | StrOutputParser()
    return chain

# @st.cache_resource
def key_info_extract(edited_key_info_df, path_list, vector):
    question1 = f"""这是医学活动相关的文件，请仔细阅读文字所有有效信息，并抽取文字中所有的{edited_key_info_df[:-1]['关键信息']}, 以表格的形式显示, 如果没有相关信息，就说没有。抽取后请重新检查你的结果，保证抽取的全面性和准确性"""
    question1_1 = f"""这是医学活动相关的文件，请仔细阅读文字所有有效信息，并抽取文字中所有的{edited_key_info_df['关键信息']}, 以表格的形式显示, 如果没有相关信息，就说没有。抽取后请重新检查你的结果，保证抽取的全面性和准确性"""
    logging.info('关键信息抽取：开始抽取')
    chain = qa_model_chain()
    vector_list = []
    batch_list = []
    for i in range(0, len(path_list)):
        if i != 2:
            vector_db_main_page_filtered = vector_db_filtered(vector, vector_query(['source'], [[path_list[i]]]))
            vector_list.append(vector_db_main_page_filtered)
            batch_list.extend([{"context": j, 'question' : question1} for j in vector_db_main_page_filtered['documents']])
        else:
            vector_db_main_page_filtered = vector_db_filtered(vector, vector_query(['source'], [[path_list[i]]]))
            vector_list.append(vector_db_main_page_filtered)
            batch_list.extend([{"context": j, 'question' : question1_1} for j in vector_db_main_page_filtered['documents']])
    
    logging.info('关键信息抽取：抽取所有块的关键信息')
    chain_result = chain.batch(batch_list)
    logging.info('关键信息抽取：抽取完毕')
    logging.info('关键信息抽取：信息整理')
    
    fetch_k_1 = len(vector_list[0]['ids'])
    raw_context_batch_result_1 = []
    for index in range(0, fetch_k_1):
        raw_context_batch_result_1.append([batch_list[index]['context'], chain_result[index]])
    
    fetch_k_2 = len(vector_list[1]['ids'])
    raw_context_batch_result_2 = []
    for index in range(fetch_k_1, fetch_k_1 + fetch_k_2):
        raw_context_batch_result_2.append([batch_list[index]['context'], chain_result[index]])    
    
    fetch_k_3 = len(vector_list[2]['ids'])
    raw_context_batch_result_3 = []
    for index in range(fetch_k_1 + fetch_k_2 , fetch_k_1 + fetch_k_2 + fetch_k_3):
        raw_context_batch_result_3.append([batch_list[index]['context'], chain_result[index]])    
    
    fetch_k_4 = len(vector_list[3]['ids'])
    raw_context_batch_result_4 = []
    for index in range(fetch_k_1 + fetch_k_2 + fetch_k_3, fetch_k_1 + fetch_k_2 + fetch_k_3 + fetch_k_4):
        raw_context_batch_result_4.append([batch_list[index]['context'], chain_result[index]])    
    
    return [[fetch_k_1, raw_context_batch_result_1, chain_result[0 : fetch_k_1]],
            [fetch_k_2, raw_context_batch_result_2, chain_result[fetch_k_1 : fetch_k_1 + fetch_k_2]],
            [fetch_k_3, raw_context_batch_result_3, chain_result[fetch_k_1 + fetch_k_2: fetch_k_1 + fetch_k_2 + fetch_k_3]],
            [fetch_k_4, raw_context_batch_result_4, chain_result[fetch_k_1 + fetch_k_2 + fetch_k_3: fetch_k_1 + fetch_k_2 + fetch_k_3 + fetch_k_4]]
           ]

def check_status(answer):
    if 'True' in answer or 'true' in answer:
        return '✅ | 仅供参考', answer
    else:
        return '❌ | 仅供参考', answer


# def get_image_base64(image_path):
#     with open(image_path, "rb") as image_file:
#         encoded_string = base64.b64encode(image_file.read()).decode()
#     if image_path.lower().endswith(".png"):
#         mime_type = "data:image/png;base64,"
#     else:  # Default to JPEG
#         mime_type = "data:image/jpeg;base64,"

#     return f"{mime_type}{encoded_string}"
    
if "cwid" not in st.session_state:
    st.session_state["cwid"] = None  
st.session_state.cwid = authentication_verification()
if st.session_state.cwid: 
    col_sidebar_1, col_sidebar_2, col_sidebar_3 = st.sidebar.columns([0.25, 0.5, 0.25]) 
    col_sidebar_2.image(Image.open('static/mapv_logo_new.png').resize((150, 150)), caption = '')
    st.sidebar.markdown(f'<div style="text-align: center">欢迎 {st.session_state.cwid} </div>', unsafe_allow_html = True)
    st.sidebar.markdown('**如果您对平台有任何建议或问题，欢迎联系：📧 EventDocReadinessCheck_Support@bayer.com**')
    st.sidebar.divider()
    st.sidebar.caption( """
    免责声明：\n
    本平台提供的内容校对服务旨在帮助用户改善和提升其提交内容的质量。尽管我们致力于确保校对服务的准确性和可靠性，但我们不对校对结果的完整性、准确性或适用性作出任何明示或暗示的保证。\n
    用户应理解，校对服务可能无法发现所有可能的错误，并且最终内容的准确性和合法性由用户自行负责。用户在依赖校对服务进行决策前，应进行独立的验证和考量。\n
    本平台及其运营者不对因使用或依赖校对服务产生的任何直接、间接、偶然、特殊或后果性损失或损害（包括但不限于利润损失、商誉损失、数据丢失或其他无形损失）承担责任。\n
    使用本平台的校对服务即表示您理解并同意本免责声明的条款。如果您不同意本声明的任何部分，请不要使用本平台的校对服务。\n
    """, unsafe_allow_html = True) 

    # <img src="static/banner_test.png" style="position:relative; left:0px; top:0px; right:0px;">

    # Read and display the image
#     image_path = "static/banner_test.png"  # Replace with your image path
#     base64_image = get_image_base64(image_path)
#     html_string = f"""
#         <img src="{base64_image}" alt="Your Image" style="width:100%; margin:0;">
#     """

#     # Display the image using HTML
#     st.markdown(html_string, unsafe_allow_html=True)

    
    bayer_banner = Image.open('static/banner_test.png')
    st.image(bayer_banner, caption = '', use_column_width = True)
    # st.markdown('<div style="text-align: center">By MAPV China </div>', unsafe_allow_html = True)
    st.info('请您：1、上传所需的全部文件；2、选择相关的会议类型；3、点击提交按钮。\n 我们会为您：1、判断Opera是否遵循公允市场价值；2、以Opera文件为对象，校对关键信息的一致性', icon = "💻")
    st_1, st_2, st_3 = st.columns([3, 1, 2])
    st_1.subheader('文件上传')
    file_upload_1_col, file_upload_2_col = st_1.columns([0.5, 0.5])
    file_upload_3_col, file_upload_4_col= st_1.columns([0.5, 0.5,])
    zhaoshang_yaoqing = file_upload_1_col.file_uploader(label = '**招商函或邀请函**', type = 'pdf', help = "- 格式：*PDF* \n - 注意事项：请尽可能保证您的PDF中需要保证内容是'可复制'的，即用任意浏览器打开文件后，文件中的内容可以被鼠标选中.")
    hetong = file_upload_2_col.file_uploader(label = '**合同**', type = ['docx', 'doc'], help = "- 格式：*Word .docx， .doc* - 注意事项：.doc文件的处理速度慢于.docx。如果您的文件是.doc希望转换成.docx，请在本地打开后，点击左上方的'File' -> 'Save As' -> 修改格式为'Word Document(*.docx)', 上传.docx格式到平台")
    fmv = file_upload_3_col.file_uploader(label = '**FMV**', type = ['docx', 'doc'], help = "- 格式：*Word .docx， .doc* - 注意事项：.doc文件的处理速度慢于.docx。如果您的文件是.doc希望转换成.docx，请在本地打开后，点击左上方的'File' -> 'Save As' -> 修改格式为'Word Document(*.docx)', 上传.docx格式到平台")
    opera = file_upload_4_col.file_uploader(label = '**Opera系统**', type = 'pdf', help = "- 格式：*PDF* \n - 注意事项：在Opera系统填写完成后 -> 右击鼠标，点击'Print' -> 在'Destination'中选择'Save as PDF' -> 保存至本地 -> 尽可能确认您的PDF中的内容是'可复制'的 -> 上传文件")

    st_2.subheader('会议类型') # , divider = 'gray'
    contract_type = st_2.radio(label = '会议类型', options = ['赞助会', ], index = 0, label_visibility = "hidden")
    st_3.subheader('关键信息表')
    key_info_df = pd.DataFrame([
        {'关键信息':'学会名称', '解释': ''}, 
        {'关键信息':'活动名称', '解释': ''},
        {'关键信息':'会议时间', '解释': ''},
        {'关键信息':'会议地点', '解释': ''},
        {'关键信息':'金额',  '解释': ''},
        {'关键信息':'赞助方权利/赞助方回报',  '解释': ''},
        {'关键信息':'FMV文件版本',  '解释': '需要用最新模板，最新的版本是3.0'},
    ])
    
    edited_key_info_df = st_3.data_editor(
        key_info_df,
        column_config={
        "关键信息": st.column_config.Column(width= None,),
        "解释": st.column_config.Column(width= 'large',),
        },
         use_container_width = False, ## if set to true, the dataframe is flickering,
         hide_index = True,
         disabled = ('关键信息', '解释'),
         num_rows = 'fixed')
    submit_button = st.button(label = '提交', type = "primary")

    if submit_button and contract_type == '赞助会' and zhaoshang_yaoqing and hetong and fmv and opera:
        logging.info('用户已点击提交button')
        try:
            vectordb, docs_fail = vector_db_prepare([[zhaoshang_yaoqing, '招商函或邀请函'], [hetong, '合同'], [fmv, 'FMV'], [opera, 'Opera系统']], st.session_state.cwid)
            if len(docs_fail) == 0:
                logging.info('文件处理完毕，len(docs_fail) == 0')
                # st.subheader('关键信息一致性校对', divider = 'gray')
                logging.info('开始判断Opera是否符合公允市场')
                main_page_bar = st.progress(0, text = f':red[💻 **EventDocReadinessCheck**：请等待大约10分钟：⚠请勿息屏、返回‘✉ 功能介绍及使用方法’界面、或点击提交按钮：] :blue[第二模块：一致性校对]  第1/5步：正在分析文件：{opera.name}中的信息是否符合 第三版本(9086) 赞助会议的公允市场价值对照表...')
                st.markdown('##### 💻 Opera是否遵循公允市场价值')
                chain = qa_model_chain()
                logging.info('读取excel表格')
                standard_table = pd.read_excel('附件-06 赞助会议的公允市场价值对照表-Times-20210301164858537.xlsx', sheet_name = 0)
                with st.expander(':blue[查看《第三版本(9086) 赞助会议的公允市场价值对照表》]'):
                    st.dataframe(standard_table)
                logging.info('开始对opera进行filter')
                opera_text = vector_db_filtered(vectordb, vector_query(['source'], [[opera.name]]))['documents'][0:10]
                logging.info('opera是否符合标准的GPT QA')
                question_if_follow_standard_fmv = f'context中是赞助会项目的单价最高金额。我希望你判断 opera_text 中的赞助项目的单价是否符合 context 中的标准，如果符合，请回答：True，并说明分析的步骤；如果不符合或无法判断，请回答：False，并说明原因。请你 1.首先，从{opera_text}中判断赞助会的类型：全国会还是区域/省级会议，必须给出一个类型； 2. 接着，抽取并列出赞助的所有项目和单价；3. 将抽取的项目和context中的标准项目做匹配；4. 然后，将抽取的项目单价和context中的标准项目单价做对比，判断是否符合要求。 \n opera_text : {opera_text}'
                answer_if_follow_standard_fmv = chain.invoke({'context' : standard_table, 'question' : question_if_follow_standard_fmv})
                logging.info('判断opera的status')
                status_follow_standard_fmv, detailed_answer_follow_standard_fmv = check_status(answer_if_follow_standard_fmv)
                opera_col1, opera_col2 = st.columns([0.1, 0.9])
                opera_col1.markdown(f':blue[**状态：**] \n {status_follow_standard_fmv}')
                opera_col2.markdown(f':blue[**详情：**] \n {detailed_answer_follow_standard_fmv}')
                logging.info('opera的对比结束')

                main_page_bar.progress(10, f':red[💻 **EventDocReadinessCheck**：请等待大约10分钟：⚠请勿息屏、返回‘✉ 功能介绍及使用方法’界面或点击提交按钮：] :blue[第二模块：一致性校对]  第2/5步：正在抽取文件：{zhaoshang_yaoqing.name}、{hetong.name}、{fmv.name}、{opera.name}中的关键信息...')
                st.divider()
                st.markdown('##### 💻 关键信息的一致性校对：以Opera文件为对象')
                st.caption("**ℹ️：结果中的'context'指的是Opera**")

                logging.info('抽取关键关键信息')
                extraction_result = key_info_extract(edited_key_info_df, [zhaoshang_yaoqing.name, hetong.name, fmv.name, opera.name], vectordb)

                fetch_k_1, raw_context_batch_result_1, zhaoshang_yaoqing_result_1 = extraction_result[0][0], extraction_result[0][1], extraction_result[0][2] 
                fetch_k_2, raw_context_batch_result_2, hetong_result_1 = extraction_result[1][0], extraction_result[1][1], extraction_result[1][2]
                fetch_k_3, raw_context_batch_result_3, fmv_result_1 = extraction_result[2][0], extraction_result[2][1], extraction_result[2][2]
                fetch_k_4, raw_context_batch_result_4, opera_result_1 = extraction_result[3][0], extraction_result[3][1], extraction_result[3][2]

                main_page_bar.progress(50, f':red[💻 **EventDocReadinessCheck**：请等待大约10分钟：⚠请勿息屏、返回‘✉ 功能介绍及使用方法’界面或点击提交按钮：] :blue[第二模块：一致性校对]  第3/5步：正在将所有文件中抽取出的信息进行整理...')
                question2 = f"""请以{edited_key_info_df[:-1]['关键信息']}作为columns的格式, 将context中的信息罗列在一个大表中，以表格的形式显示。请注意不要合并或丢失任何信息。"""
                question2_2 = f"""请以{edited_key_info_df['关键信息']}作为columns的格式, 将context中的信息罗列在一个大表中，以表格的形式显示。请注意不要合并或丢失任何信息。"""
                logging.info('合并文件的信息')
                combine_result = chain.batch([{'context' : zhaoshang_yaoqing_result_1, 'question' : question2}, {'context' : hetong_result_1, 'question' : question2}, {'context' : fmv_result_1, 'question' : question2_2}, {'context' : opera_result_1, 'question' : question2}])
                zhaoshang_yaoqing_result, hetong_result, fmv_result, opera_result = combine_result[0], combine_result[1], combine_result[2], combine_result[3]

                logging.info('正在对比其他文件与Opera的一致性：GPT开始')

                main_page_bar.progress(60, f':red[💻 **EventDocReadinessCheck**：请等待大约10分钟：⚠请勿息屏、返回‘✉ 功能介绍及使用方法’界面或点击提交按钮：] :blue[第二模块：一致性校对]  第4/5步：正在对比其他文件与Opera文件中关键信息的一致性...')
                answer_if_consist_opera = chain.batch([{'context' : opera_result, 'question' : f"请按照{edited_key_info_df[:-1]['关键信息']}的顺序，判断{zhaoshang_yaoqing_result}的信息是否符合context中的相关信息，请注意：格式的不一致，不代表不一致。如果一致，请回答：True，并说明分析的步骤；如果不一致，请回答：False，并说明具体的原因。请高亮重点信息。"},{'context' : opera_result, 'question' : f"请按照{edited_key_info_df[:-1]['关键信息']}的顺序，判断{hetong_result}的信息是否符合context中的相关信息，请注意：格式的不一致，不代表不一致。如果一致，请回答：True，并说明分析的步骤；如果不一致，请回答：False，并说明具体的原因。请高亮重点信息。"}, {'context' : opera_result, 'question' : f"请按照{edited_key_info_df[:-1]['关键信息']}的顺序，判断FMV的信息：{fmv_result}是否符合context中的相关信息，请注意：格式的不一致，不代表不一致。如果一致，请回答：True，并说明分析的步骤；如果不一致，请回答：False，并说明具体的原因。请高亮重点信。对于FMV中的‘版本’，请判断是否使用了最新版本3.0，如果没有，请给出“模板使用有有误，建议您使用最新FMV模板，即3.0版本”；如果使用了，请回答：“模板使用正确，为最新版本3.0” "}])
                logging.info('正在对比其他文件与Opera的一致性：GPT结束')

                main_page_bar.progress(90, f':red[💻 **EventDocReadinessCheck**：请等待大约10分钟：⚠请勿息屏、返回‘✉ 功能介绍及使用方法’界面或点击提交按钮：] :blue[第二模块：一致性校对]  第5/5步：正在撰写最终报告...')
                logging.info('正在把对比的GPT的结果和status check匹配')
                status_if_consist_opera_zhaoshang, detailed_answer_if_consist_opera_zhaoshang = check_status(answer_if_consist_opera[0])
                status_if_consist_opera_hetong,  detailed_answer_if_consist_opera_hetong = check_status(answer_if_consist_opera[1])
                status_if_consist_opera_fmv,  detailed_answer_if_consist_opera_fmv = check_status(answer_if_consist_opera[2])   

                logging.info('正撰写报告')
                zhaoshang_col1, zhaoshang_col2, zhaoshang_col3 = st.columns([0.1, 0.1, 0.8])
                zhaoshang_col1.markdown(f':blue[**文件：**] \n {zhaoshang_yaoqing.name}')
                zhaoshang_col2.markdown(f':blue[**状态：**] \n {status_if_consist_opera_zhaoshang}')
                zhaoshang_col3.markdown(f':blue[**详情：**] \n {detailed_answer_if_consist_opera_zhaoshang}')
                with st.expander('查看对比结果'):
                    col11, col12 = st.columns([0.5, 0.5])
                    col11.write('**招商函或邀请函** \n ')
                    col11.markdown(f'{zhaoshang_yaoqing_result}')
                    col12.write(f'**Opera系统** \n ')
                    col12.markdown(f'{opera_result}') 

                col13, col14 = st.columns([0.5, 0.5])
                with col13.expander(f'**招商函或邀请函**：共有{fetch_k_1}块文件，每块的原文与抽取结果'):
                    for i in range(len(raw_context_batch_result_1)):
                        st.markdown(f'第{i}块的原文与抽取结果')
                        st.caption(raw_context_batch_result_1[i][0])
                        st.divider()
                        st.write(raw_context_batch_result_1[i][1])
                with col14.expander(f'**Opera系统**：共有{fetch_k_4}块文件，每块的原文与抽取结果'):
                    for i in range(len(raw_context_batch_result_4)):
                        st.markdown(f'第{i}块的原文与抽取结果')
                        st.caption(raw_context_batch_result_4[i][0])
                        st.write(raw_context_batch_result_4[i][1])
 


                hetong_col1, hetong_col2, hetong_col3 = st.columns([0.1, 0.1, 0.8])
                hetong_col1.markdown(f':blue[**文件：**] \n {hetong.name}')
                hetong_col2.markdown(f':blue[**状态：**] \n {status_if_consist_opera_hetong}')
                hetong_col3.markdown(f':blue[**详情：**] \n {detailed_answer_if_consist_opera_hetong}')
                with st.expander('查看抽取结果'):
                    col21, col22 = st.columns([0.5, 0.5])
                    col21.write(f'**合同** \n')
                    col21.markdown(f'{hetong_result}')
                    col22.write(f'**Opera系统** \n')
                    col22.markdown(f'{opera_result}')
                col23, col24 = st.columns([0.5, 0.5])
                with col23.expander(f'**合同**：共有{fetch_k_2}块文件，每块的原文与抽取结果'):
                    for i in range(len(raw_context_batch_result_2)):
                        st.markdown(f'第{i}块的原文与抽取结果')
                        st.caption(raw_context_batch_result_2[i][0])
                        st.write(raw_context_batch_result_2[i][1])
                with col24.expander(f'**Opera系统**：共有{fetch_k_4}块文件，每块的原文与抽取结果'):
                    for i in range(len(raw_context_batch_result_4)):
                        st.markdown(f'第{i}块的原文与抽取结果')
                        st.caption(raw_context_batch_result_4[i][0])
                        st.write(raw_context_batch_result_4[i][1])



                fmv_col1, fmv_col2, fmv_col3 = st.columns([0.1, 0.1, 0.8])
                fmv_col1.markdown(f':blue[**文件：**] \n {fmv.name}')
                fmv_col2.markdown(f':blue[**状态：**] \n {status_if_consist_opera_fmv}')
                fmv_col3.markdown(f':blue[**详情：**] \n {detailed_answer_if_consist_opera_fmv}')
                with st.expander('查看抽取结果'):
                    col31, col32 = st.columns([0.5, 0.5])
                    col31.write(f'**FMV** \n')
                    col31.markdown(f'{fmv_result}')
                    col32.write(f'**Opera系统** \n')
                    col32.markdown(f'{opera_result}')

                col33, col34 = st.columns([0.5, 0.5])
                with col33.expander(f'**FMV**：共有{fetch_k_3}块文件，每块的原文与抽取结果'):
                    for i in range(len(raw_context_batch_result_3)):
                        st.markdown(f'第{i}块的原文与抽取结果')
                        st.caption(raw_context_batch_result_3[i][0])
                        st.write(raw_context_batch_result_3[i][1])
                with col34.expander(f'**Opera系统**：共有{fetch_k_4}块文件，每块的原文与抽取结果'):
                    for i in range(len(raw_context_batch_result_4)):
                        st.markdown(f'第{i}块的原文与抽取结果')
                        st.caption(raw_context_batch_result_4[i][0])
                        st.write(raw_context_batch_result_4[i][1])
                main_page_bar.empty()
                logging.info('最后报告撰写结束')
            else:
                st.error(f'您所上传的文件有误，请详细检查下列文件', icon = "❗")
                for i in docs_fail:
                    if i == '招商函或邀请函':
                        st.write(f"**{i}**所上传的文件有误，请检查：\n - 格式：*PDF* \n - 注意事项：请尽可能保证您的PDF中需要保证内容是'可复制'的，即用任意浏览器打开文件后，文件中的内容可以被鼠标选中.")
                        st.divider()
                    if i == '合同':
                        st.write(f"**{i}**所上传的文件有误，请检查：\n - 格式：*Word .docx， .doc* - 注意事项：.doc文件的处理速度慢于.docx。如果您的文件是.doc希望转换成.docx，请在本地打开后，点击左上方的'File' -> 'Save As' -> 修改格式为'Word Document(*.docx)', 上传.docx格式到平台")
                        st.divider()
                    if i == 'FMV':
                        st.write(f"**{i}**所上传的文件有误，请检查：\n - 格式：*Word .docx， .doc* - 注意事项：.doc文件的处理速度慢于.docx。如果您的文件是.doc希望转换成.docx，请在本地打开后，点击左上方的'File' -> 'Save As' -> 修改格式为'Word Document(*.docx)', 上传.docx格式到平台")
                        st.divider()
                    if i == 'Opera系统':
                        st.write(f"**{i}**所上传的文件有误，请检查：\n - 格式：*PDF* \n - 注意事项：在Opera系统填写完成后 -> 右击鼠标，点击'Print' -> 在'Destination'中选择'Save as PDF' -> 保存至本地 -> 尽可能确认您的PDF中的内容是'可复制'的 -> 上传文件")
                        st.divider()
        except Exception as e:
            st.warning('请您尝试关闭网页重新进入；如果仍旧存在问题：请联系 📧 EventDocReadinessCheck_Support@bayer.com；如果您的需求非常紧急，请联系📧 danping.jia@bayer.com', icon = "⚠️")
else:
    st.info('很抱歉，你没有访问权限。请联系：📧 EventDocReadinessCheck_Support@bayer.com', icon = "ℹ️")

